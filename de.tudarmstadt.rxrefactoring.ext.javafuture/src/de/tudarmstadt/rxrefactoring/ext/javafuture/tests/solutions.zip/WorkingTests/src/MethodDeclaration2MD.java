

import io.reactivex.Observable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class MethodDeclaration2MD {
	
	// Refactor
	public Observable<Integer> retFuture(){
		ExecutorService exec = Executors.newSingleThreadExecutor();
		Observable<Integer> fObservable = Observable.fromFuture(exec.submit(new MyCallable1()));
		return fObservable;
	}
	
	//Dont refactor
	public Future<String> retFuture2(int i) throws InterruptedException, ExecutionException{
		ExecutorService exec = Executors.newSingleThreadExecutor();
		Future<String> f = exec.submit(new MyCallable2());
		if (i<2)
			f.cancel(true);
		else
			f.get();
		return f;
	}
}
