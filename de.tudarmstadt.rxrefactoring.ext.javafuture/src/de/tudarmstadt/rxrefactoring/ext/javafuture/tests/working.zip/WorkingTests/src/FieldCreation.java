
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * This case tests that if two different methods assign a value to a field,
 * if one of these values cannot be refactored, then the field and the other
 * assignment aren't either.
 */
public class FieldCreation {
	
	// Refactor
	static Future<Integer> f1;
	// Dont refactor
	static Future<Integer> f2;
	
	public static void main(String[] args) throws Exception{
		
		ExecutorService exec = Executors.newSingleThreadExecutor();
		f1 = exec.submit(new MyCallable1());
		f2 = exec.submit(new MyCallable1());
		f2.cancel(true);
	}
	
	public void meth() {
		ExecutorService exec = Executors.newSingleThreadExecutor();
		f1 = exec.submit(new MyCallable1());
		f2 = exec.submit(new MyCallable1());
	}
}



