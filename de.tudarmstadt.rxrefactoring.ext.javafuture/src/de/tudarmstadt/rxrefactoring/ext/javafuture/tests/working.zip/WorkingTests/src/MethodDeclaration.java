
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * This case makes sure that a Method Declaration that returns a Future
 * is not refactored if at least one value returned cannot be refactored.
 */
public class MethodDeclaration {
	
	//Refactor
	static Future<Integer> fF;
	
	public static void main(String[] args) throws Exception{
		
		MethodDeclarationMD md = new MethodDeclarationMD();
		// Refactor
		fF = md.retFuture(); // Dont change method
		fF.get();
		
		// Dont refactor
		Future<String> f1 = md.retFuture2(1);
		f1.cancel(true);
		
		// Refactor
		Future<String> f2 = md.retFuture2(1); // Change method
		f2.get();
		
		// Refactor
		Future<String> f3 = retFuture2(1); // Dont change method
		
		// Dont refactor
		Future<Integer> f4 = retFuture();
		f4.cancel(true);
		
		// Refactor
		Future<Integer> f5 = retFuture(); // Change method
	}
	
	// Dont refactor
	public static Future<Integer> retFuture(){
		ExecutorService exec = Executors.newSingleThreadExecutor();
		return exec.submit(new MyCallable1());
	}
	
	// Refactor
	public static Future<String> retFuture2(int i){
		ExecutorService exec = Executors.newSingleThreadExecutor();
		Future<String> f = exec.submit(new MyCallable2());
		return f;
	}

}



