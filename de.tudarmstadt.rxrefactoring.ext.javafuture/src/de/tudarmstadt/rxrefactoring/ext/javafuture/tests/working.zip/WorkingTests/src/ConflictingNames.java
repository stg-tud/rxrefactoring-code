
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * The refactoring should handle equivalent names which are different bindings.
 */
public class ConflictingNames {
	
	// Dont refactor
	static Future<Integer> fF1;
	// Refactor
	static Future<Integer> fF2;
	
	public static void main(String[] args) throws Exception{
		
		ExecutorService exec = Executors.newSingleThreadExecutor();
		// NO
		fF1 = exec.submit(new MyCallable1());
		// YES
		fF2 = exec.submit(new MyCallable1());
		// NO
		fF1.cancel(true);
		// YES
		fF2.get();
		
		// YES
		Future<Integer> fF1 = exec.submit(new MyCallable1());
		// NO
		Future<Integer> fF2 = exec.submit(new MyCallable1());
		// NO
		fF2.get();
		fF2.cancel(true);
	}
}



