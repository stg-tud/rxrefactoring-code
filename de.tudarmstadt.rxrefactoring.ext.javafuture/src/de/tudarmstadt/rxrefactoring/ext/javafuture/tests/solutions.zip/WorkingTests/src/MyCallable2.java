
import java.util.concurrent.Callable;

public class MyCallable2 implements Callable<String> {

	@Override
	public String call() throws Exception {
		return "a";
		}
		
	}  