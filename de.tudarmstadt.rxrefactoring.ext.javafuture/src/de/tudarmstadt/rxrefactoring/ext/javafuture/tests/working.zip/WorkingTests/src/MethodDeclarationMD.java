
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class MethodDeclarationMD {
	// Refactor
	public Future<Integer> retFuture(){
		ExecutorService exec = Executors.newSingleThreadExecutor();
		return exec.submit(new MyCallable1());
	}
	//Dont refactor
	public Future<String> retFuture2(int i){
		ExecutorService exec = Executors.newSingleThreadExecutor();
		Future<String> f = exec.submit(new MyCallable2());
		return f;
	}

}
