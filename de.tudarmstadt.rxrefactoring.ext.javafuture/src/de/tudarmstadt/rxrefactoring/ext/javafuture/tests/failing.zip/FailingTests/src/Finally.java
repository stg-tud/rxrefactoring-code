
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * This case shows a situation where the method call in finally is
 * not identified because 'finally is only partially supported'.
 * An example of this situation can be found in 
 * org.springside.modules.utils.concurrent.jsr166e.ForkJoinPool
 *
 * Update 23.06.2018: Error thrown when refactoring should take place
 * in try catch blocks.
 * org.eclipse.text.edits.MalformedTreeException: Source edit has different target edit.
 */
public class Finally {
	
	public void meth(){
		
		ExecutorService exec = Executors.newSingleThreadExecutor();
		
		Future<Integer> f = exec.submit(new MyCallable1());
		
		try {
			f.get();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			f.cancel(true);
		}
		
	}
	

}



