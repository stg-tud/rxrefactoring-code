
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * Here, the workaround does not work because the uses for the assignment
 * and method invocations which are not later used are not stored by
 * the use def analysis.
 *
 */
public class FieldUses2 {
	
	Future<Integer> f1; 
	Future<Integer> f2;
	
	public void method1() throws Exception {
		ExecutorService exec = Executors.newSingleThreadExecutor();
		
		f1 = exec.submit(new MyCallable1());
		f2 = exec.submit(new MyCallable1());
		
	}
	
	private void method2(){
		// The name of f1 is refactored, but the new variable is not.
		Future<Integer> f1Internal = f1;
		// f2 is refactored because the unsupported method is not registered.
		f2.cancel(true);
	}

	}

