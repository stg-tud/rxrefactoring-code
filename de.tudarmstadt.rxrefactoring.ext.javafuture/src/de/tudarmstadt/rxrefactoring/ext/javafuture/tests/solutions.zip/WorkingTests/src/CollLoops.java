
import io.reactivex.Observable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;


/**
 * This case tests that different loops of Future collections can be handled.
 *
 */
public class CollLoops {
	
	public static void main(String[] args) throws Exception{
		
		ExecutorService exec = Executors.newSingleThreadExecutor();
		
		// Refactor
		
		ArrayList<Observable<Integer>> coll1Observables;
		coll1Observables = new ArrayList<Observable<Integer>>();
		
		for (int i=0;i<5;i++) {
			// Refactor type and name, not get
			Observable<Integer> fObservable = coll1Observables.get(2);
			// Refactor only second get
			Integer in = coll1Observables.get(1).blockingSingle();
		}
		
		for (int i=0;i<5;i++) {
			coll1Observables.add(Observable.fromFuture(exec.submit(new MyCallable1())));
		}
		
		 Iterator<Observable<Integer>> it = coll1Observables.iterator();
		    while(it.hasNext()) {
		      Observable<Integer> fObservable = it.next();
		      fObservable.blockingSingle();
		    
		 }
		
		for(Observable<Integer> sObservable : coll1Observables) {
			sObservable.blockingSingle();
		}
		
		coll1Observables.forEach(fObservable -> {
			fObservable.blockingSingle();
		});
		
		coll1Observables.forEach((Observable fObservable) -> {
			fObservable.blockingSingle();
		});
		
		// Dont refactor anything below here
		ArrayList<Future<Integer>> coll2 = new ArrayList<Future<Integer>>();
		ArrayList<Future<Integer>> coll3 = new ArrayList<Future<Integer>>();
		
		for (int i=0;i<5;i++) {
			coll2.add(exec.submit(new MyCallable1()));
		}
		 
		for (int i=0;i<5;i++) {
			Future<Integer> f = coll2.get(2);
			Integer in = coll2.get(2).get();
		}
		
		for(Future<Integer> s : coll2) {
			s.get();
		}

		 Iterator<Future<Integer>> it2 = coll2.iterator();
		    while(it2.hasNext()) {
		      Future<Integer> f = it2.next();
		 }
		 Iterator<Future<Integer>> it3 = coll3.iterator();
		    while(it3.hasNext()) {
		      Future<Integer> f = it3.next();
		      f.isDone();
		 }
		    
		coll2.forEach(f -> {
			try {
				f.cancel(true);
			} catch (Exception e) {
			}
		});
		
		
	}

}



