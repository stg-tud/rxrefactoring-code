
import java.util.concurrent.Future;

public class ParamMethodDeclarationMD {
	public void retFuture(Future<Integer> f){

	}
}
