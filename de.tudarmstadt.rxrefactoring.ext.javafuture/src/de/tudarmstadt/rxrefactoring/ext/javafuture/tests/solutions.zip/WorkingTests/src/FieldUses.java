
import io.reactivex.Observable;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * This case shows the workaround using bindings that allows to link 
 * fields initialized in some method with its uses within another method. 
 * In the use def analysis, these uses are not directly associated with 
 * their declarations. However, this should work because if at least one
 * declaration associated with a variable cannot be refactored, then none 
 * should be.
 *
 */
public class FieldUses {
	
	protected List<Future<?>> tasks1;
	protected List<Future<?>> tasks2;
	
	protected List<Observable<?>> tasks1RObservables;
	protected List<Observable<?>> tasks2RObservables;
	
	public void method1() throws Exception {
		ExecutorService exec = Executors.newSingleThreadExecutor();
		
		tasks1 = new ArrayList<Future<?>>( 3 );
		tasks2 = new ArrayList<Future<?>>( 3 );
		
		tasks1RObservables = new ArrayList<Observable<?>>( 3 );
		tasks2RObservables = new ArrayList<Observable<?>>( 3 );
	}
	
	private void method2() throws Exception {
		
		for (Future f : tasks1) {
			f.cancel(true);
			}
		
		tasks2.get(1).cancel(true);
		
		
		for (Observable fObservable : tasks1RObservables) {
			fObservable.blockingSingle();
			}
		
		tasks2RObservables.get(1).blockingSingle();
		
	}

	}

