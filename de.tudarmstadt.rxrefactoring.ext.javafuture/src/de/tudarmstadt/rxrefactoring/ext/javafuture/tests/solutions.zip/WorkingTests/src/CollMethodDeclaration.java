
import io.reactivex.Observable;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * Analogous to methodDeclaration but with collections.
 */
public class CollMethodDeclaration {
	
	// YES
	static List<Observable<String>> collF1Observables;
	
	public static void main(String[] args) throws Exception{
		
		CollMethodDeclarationMD md = new CollMethodDeclarationMD();
		
		// YES
		collF1Observables = md.retFuture(); // Dont change method
		collF1Observables.get(1).blockingSingle();
		
		// NOT
		List<Future<String>> coll1 = md.retFuture2(1);
		coll1.get(1).cancel(true);
		
		// NOT
		List<Future<String>> coll2 = md.retFuture2(2);
		coll2.get(1).get();
		
		// YES
		List<Observable<String>> coll3Observables = retFuture2(1, "hi"); // Dont change method
		
		// NOT
		List<Future<String>> coll4 = retFuture();
		coll4.get(1).cancel(true);
		
		// NOT
		List<Future<String>> coll5 = retFuture();
		coll5.get(1).get();
	}
	
	// NO
	public static List<Future<String>> retFuture(){
		ExecutorService exec = Executors.newSingleThreadExecutor();
		List<Future<String>> c = new ArrayList<Future<String>>();
		c.add(exec.submit(new MyCallable2()));
		return c;
	}
	// YES
	public static <T> List<Observable<T>> retFuture2(int i, T s){
		ExecutorService exec = Executors.newSingleThreadExecutor();
		List<Observable<T>> cObservables = new ArrayList<Observable<T>>();
		return cObservables;
	}

}



