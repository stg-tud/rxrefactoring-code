
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * This case shows that if a field is initialized outside a method, which is 
 * particularly common for collections, the uses of the declaration within 
 * methods are not stored.
 *
 */
public class CollFieldCreation {
	
	// NO
	static List<Future<Integer>> collF1 = new ArrayList<Future<Integer>>();
	// YES
	static ArrayList<Future<Integer>> collF2 = new ArrayList<Future<Integer>>();
	
	public static void main(String[] args) throws Exception{
		
		ExecutorService exec = Executors.newSingleThreadExecutor();
		// NO
		collF1.add(exec.submit(new MyCallable1()));
		collF1.get(1).cancel(true);
		// YES
		collF2.add(exec.submit(new MyCallable1()));
	}
}



