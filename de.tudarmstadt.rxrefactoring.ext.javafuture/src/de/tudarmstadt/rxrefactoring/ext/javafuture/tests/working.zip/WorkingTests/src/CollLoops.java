
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;


/**
 * This case tests that different loops of Future collections can be handled.
 *
 */
public class CollLoops {
	
	public static void main(String[] args) throws Exception{
		
		ExecutorService exec = Executors.newSingleThreadExecutor();
		
		// Refactor
		
		ArrayList<Future<Integer>> coll1;
		coll1 = new ArrayList<Future<Integer>>();
		
		for (int i=0;i<5;i++) {
			// Refactor type and name, not get
			Future<Integer> f = coll1.get(2);
			// Refactor only second get
			Integer in = coll1.get(1).get();
		}
		
		for (int i=0;i<5;i++) {
			coll1.add(exec.submit(new MyCallable1()));
		}
		
		 Iterator<Future<Integer>> it = coll1.iterator();
		    while(it.hasNext()) {
		      Future<Integer> f = it.next();
		      f.get();
		    
		 }
		
		for(Future<Integer> s : coll1) {
			s.get();
		}
		
		coll1.forEach(f -> {
			try {
				f.get();
			} catch (Exception e) {
			}
		});
		
		coll1.forEach((Future f) -> {
			try {
				// YES
				f.get();
			} catch (Exception e) {
			}
		});
		
		// Dont refactor anything below here
		ArrayList<Future<Integer>> coll2 = new ArrayList<Future<Integer>>();
		ArrayList<Future<Integer>> coll3 = new ArrayList<Future<Integer>>();
		
		for (int i=0;i<5;i++) {
			coll2.add(exec.submit(new MyCallable1()));
		}
		 
		for (int i=0;i<5;i++) {
			Future<Integer> f = coll2.get(2);
			Integer in = coll2.get(2).get();
		}
		
		for(Future<Integer> s : coll2) {
			s.get();
		}

		 Iterator<Future<Integer>> it2 = coll2.iterator();
		    while(it2.hasNext()) {
		      Future<Integer> f = it2.next();
		 }
		 Iterator<Future<Integer>> it3 = coll3.iterator();
		    while(it3.hasNext()) {
		      Future<Integer> f = it3.next();
		      f.isDone();
		 }
		    
		coll2.forEach(f -> {
			try {
				f.cancel(true);
			} catch (Exception e) {
			}
		});
		
		
	}

}



