
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * This is a minimal test case that shows a problem in the parallelization.
 * When two threads try to create new SimpleNames at the same time (note that 
 * this also occurs, for instance, when a new Type is created or by calls to 
 * ASTNode.copySubtree) using the same AST, this may throw an exception. 
 * 
 * The ‘newSimpleName(String identifier)’ method in AST calls 
 * ‘setIdentifier(String identifier)’ from SimpleName. There, the 'currentPosition' 
 * of the Scanner (which is an AST field) is changed first to 0 and then according 
 * to the length of the identifier String that is the parameter of the method. If 
 * within these steps 'currentPosition is changed because another SimpleName is in 
 * creation, a later check ‘scanner.currentPosition != length’ throws an 
 * IllegalArgumentException("Invalid identifier : >" + identifier + "<").
 *
 */
public class Paralellization {
	
	public void meth() throws Exception{
		
		ExecutorService exec = Executors.newSingleThreadExecutor();
		
		Future<Integer> f1 = exec.submit(new MyCallable1());
		Future<Integer> f2 = exec.submit(new MyCallable1());
		
	}
	

}



