
import java.util.concurrent.*;

public class MyCallable1 implements Callable<Integer> {

    @Override
    public Integer call() throws Exception {
        return 1;
    }
}