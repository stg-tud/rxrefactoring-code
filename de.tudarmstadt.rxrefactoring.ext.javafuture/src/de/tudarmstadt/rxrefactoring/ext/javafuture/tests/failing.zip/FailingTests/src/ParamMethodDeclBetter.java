
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * This case shows when parameters should be refactored. However, it currently
 * is not implemented because the uses of method parameters are not stored by the use def analysis.
 *
 */
public class ParamMethodDeclBetter {
	
	public void meth() throws Exception{
		
		ExecutorService exec = Executors.newSingleThreadExecutor();
		
		ParamMethodDeclBetterMD md = new ParamMethodDeclBetterMD();
		
		// Refactor
		Future<Integer> f1 = exec.submit(new MyCallable1());
		md.retFuture(f1);
		
		// Dont refactor because method cannot be refactored
		Future<Integer> f2 = exec.submit(new MyCallable1());
		md.retFuture2(f2);
		
		// Dont refactor because f3 cannot be refactored
		Future<Integer> f3 = exec.submit(new MyCallable1());
		md.retFuture3(f3);
		f3.isDone();
		Future<Integer> f4 = exec.submit(new MyCallable1());
		md.retFuture3(f4);
		
		// Refactor
		List<Future<Integer>> cf1 = new ArrayList<Future<Integer>>();
		retFuture(cf1);
		
		// Dont refactor because method cannot be refactored
		List<Future<Integer>> cf2 = new ArrayList<Future<Integer>>();
		retFuture2(cf2);
		
		// Dont refactor because f3 cannot be refactored
		List<Future<Integer>> cf3 = new ArrayList<Future<Integer>>();
		retFuture3(cf3);
		f3.isDone();
		List<Future<Integer>> cf4 = new ArrayList<Future<Integer>>();
		retFuture3(cf4);
		
		
	}
	
	// Refactor
	public void retFuture(List<Future<Integer>> f){
	}
	
	//Dont refactor because parameter variable cannot be refactored
	public void retFuture2(List<Future<Integer>> f){
		f.get(1).cancel(true);
	}
	
	//Dont refactor bacause argument cannot be refactored
	public void retFuture3(List<Future<Integer>> f){
	}
	

}



