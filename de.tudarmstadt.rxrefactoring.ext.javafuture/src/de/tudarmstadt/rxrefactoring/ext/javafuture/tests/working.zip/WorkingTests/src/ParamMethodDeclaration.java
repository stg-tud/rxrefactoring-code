
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * Futures passed as arguments to a method should not be refactored.
 * A better behavior would be that in ParamMethodDeclarationBetter,
 * but that is currently not compatible with the use def analysis.
 *
 */
public class ParamMethodDeclaration {
	
	public static void main(String[] args) throws Exception{
		
		ExecutorService exec = Executors.newSingleThreadExecutor();
		
		ParamMethodDeclarationMD md = new ParamMethodDeclarationMD();
		
		// Dont refactor
		Future<Integer> f = exec.submit(new MyCallable1());
		md.retFuture(f);
		
		// Dont refactor
		List<Future<Integer>> colF = new ArrayList<Future<Integer>>();
		retFuture(colF);
	}
	
	public static void retFuture(List<Future<Integer>> f){
	}
	

}



