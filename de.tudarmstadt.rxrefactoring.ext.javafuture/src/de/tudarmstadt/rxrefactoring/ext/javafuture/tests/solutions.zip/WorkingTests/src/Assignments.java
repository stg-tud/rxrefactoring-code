
import io.reactivex.Observable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class Assignments {
	
	static Future<Integer> f1;
	
	public static void main(String[] args) throws Exception{
		
		ExecutorService exec = Executors.newSingleThreadExecutor();
		
		//None should be refactored
		f1 = exec.submit(new MyCallable1());
		Future<Integer> f2 = exec.submit(new MyCallable1());
		f2.cancel(true);
		f1 = f2;
		
		//None should be refactored
		Future<Integer> f3 = exec.submit(new MyCallable1());
		Future<Integer> f4 = exec.submit(new MyCallable1());
		f4.cancel(true);
		f4 = f3;
		
		//Both should be refactored
		Observable<Integer> f5Observable = Observable.fromFuture(exec.submit(new MyCallable1()));
		Observable<Integer> f6Observable = Observable.fromFuture(exec.submit(new MyCallable1()));
		f5Observable.blockingSingle();
		f5Observable = f6Observable;
	}

}



