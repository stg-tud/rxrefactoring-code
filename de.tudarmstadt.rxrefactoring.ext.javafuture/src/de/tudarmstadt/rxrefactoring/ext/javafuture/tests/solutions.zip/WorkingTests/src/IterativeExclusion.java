
import io.reactivex.Observable;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * This case tests several situations where an instance or a collection is not refactored.
 * Only instances with names ending with 'R'
 */
public class IterativeExclusion {
	
	static List<Future<Integer>> cf1;
	
	static List<Observable<Integer>> cf1RObservables;
	
	public static void main(String[] args) throws Exception{
		
		ExecutorService exec = Executors.newSingleThreadExecutor();
		
		// f3 should not be refactored because of the unsupported method call 'isDone'
		Future<Integer> f3 = exec.submit(new MyCallable1());
		f3.isDone();
		
		// cf1 is assigned cf2, so cf1 should not be refactored
		cf1 = new ArrayList<Future<Integer>>();
		
		// f1 is added to cf1, so f1 should not be refactored
		Future<Integer> f1 = exec.submit(new MyCallable1());
		cf1.add(f1);
		
		// f2 is gotten from cf2, so cf2 should not be refactored
		List<Future<Integer>> cf2 = new ArrayList<Future<Integer>>();
		
		// f2 is assigned to f3, so f2 should not be refactored
		Future<Integer> f2 = cf2.get(0);
		f3 = f2;
		
		cf1 = cf2;
		
		// Here, everything should be refactored
		Observable<Integer> f3RObservable = Observable.fromFuture(exec.submit(new MyCallable1()));
		
		cf1RObservables = new ArrayList<Observable<Integer>>();

		Observable<Integer> f1RObservable = Observable.fromFuture(exec.submit(new MyCallable1()));
		cf1RObservables.add(f1RObservable);
		
		List<Observable<Integer>> cf2RObservables = new ArrayList<Observable<Integer>>();
		
		Observable<Integer> f2RObservable = cf2RObservables.get(0);
		f3RObservable = f2RObservable;
		
		cf1RObservables = cf2RObservables;
	}

}



