
import io.reactivex.Observable;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * A simple case of not refactoring collections or items that belong to one
 * if at least one item added to it or gotten from it cannot be refactored.
 *
 */
public class CollSimple {
	
	// Refactor
	static Observable<Integer> fF1Observable;
	
	// Dont refactor
	static Future<Integer> fF2;
	
	// YES
	static List<Observable<Integer>> collF1Observables;
	
	// NO
	static ArrayList<Future<Integer>> collF2;
	
	public static void main(String[] args) throws Exception{
		
		ExecutorService exec = Executors.newSingleThreadExecutor();
		
		// YES
		collF1Observables = new ArrayList<Observable<Integer>>();
		
		// NO
		collF2 = new ArrayList<Future<Integer>>();
		
		// YES
		fF1Observable = Observable.fromFuture(exec.submit(new MyCallable1()));
		fF1Observable.blockingSingle();
		collF1Observables.add(fF1Observable);
		
		// NO
		fF2 = exec.submit(new MyCallable1());
		fF2.get();
		collF2.add(fF2);
		

		// NO
		Future<Integer> f1 = exec.submit(new MyCallable1());
		f1.cancel(true);
		collF2.add(f1);
		
		List<Callable<Integer>> tasks = new ArrayList<>();
		tasks.add(new MyCallable1());
		
		// YES
		ArrayList<Observable<Integer>> coll1Observables = new ArrayList<Observable<Integer>>();
		
		// YES
		for (int i=0;i<5;i++) {
			coll1Observables.add(Observable.fromFuture(exec.submit(new MyCallable1())));
		}
		
		// YES
		for (int i=0;i<5;i++) {
			// YES name, NO get
			Observable<Integer> fObservable = coll1Observables.get(2);
			// YES only second get
			Integer in = coll1Observables.get(2).blockingSingle();
		}
		
		//NO
		List<Future<Integer>> coll2 = exec.invokeAll(tasks);
		for (int i=0;i<5;i++) {
			Future<Integer> f = coll2.get(2);
		}
		
	}

}



