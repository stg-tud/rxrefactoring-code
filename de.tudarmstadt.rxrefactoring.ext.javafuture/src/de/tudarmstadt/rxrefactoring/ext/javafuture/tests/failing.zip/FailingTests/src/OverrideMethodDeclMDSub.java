import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class OverrideMethodDeclMDSub extends OverrideMethodDeclMD{
	
	@Override
	public Future<Integer> retFuture(){
		ExecutorService exec = Executors.newSingleThreadExecutor();
		return exec.submit(new MyCallable1());
	}

}
