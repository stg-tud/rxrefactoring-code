import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class OverrideMethodDeclMD {

	public Future<Integer> retFuture() {
		ExecutorService exec = Executors.newSingleThreadExecutor();
		Future<Integer> f = exec.submit(new MyCallable1());
		return f;
	}

}
