
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class CollAssignments {
	
	static List<Future<Integer>> cf1;
	
	public static void main(String[] args) throws Exception{
		
		ExecutorService exec = Executors.newSingleThreadExecutor();
		
		//None should be refactored
		cf1 = new ArrayList<Future<Integer>>();
		List<Future<Integer>> cf2 = new ArrayList<Future<Integer>>();
		Future<Integer> f = exec.submit(new MyCallable1());
		f.cancel(true);
		cf1.add(f);
		cf1 = cf2;
		
		//None should be refactored
		List<Future> cf3 = new ArrayList<Future>();
		List<Future> cf4 = new ArrayList<Future>();
		cf4.get(1).cancel(true);
		cf3 = cf4;
		
		//Both should be refactored
		List<Future<Integer>> cf5 = new ArrayList<Future<Integer>>();
		List<Future<Integer>> cf6 = new ArrayList<Future<Integer>>();
		Future<Integer> f2Observable = exec.submit(new MyCallable1());
		cf5.add(f2Observable);
		Integer i = cf6.get(1).get();
		cf5 = cf6;
		cf6 = cf5;
	}

}



