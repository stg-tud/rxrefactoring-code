
import java.util.List;
import java.util.concurrent.Future;

/**
 * This is not yet implemented, but a method declaration should not be refactored if:
 * - it overrides one that should not be refactored
 * - at least one declaration that overrides it should not be refactored
 */
public class OverrideMethodDecl {
	
	protected List<Future<?>> tasks;

	public void method() throws Exception {
	
		OverrideMethodDeclMD md = new OverrideMethodDeclMD();
		OverrideMethodDeclMD mds = new OverrideMethodDeclMDSub();
		
		Future<Integer> f1 = md.retFuture();
		f1.cancel(true);
		Future<Integer> f2 = mds.retFuture();
		
	}
	}

