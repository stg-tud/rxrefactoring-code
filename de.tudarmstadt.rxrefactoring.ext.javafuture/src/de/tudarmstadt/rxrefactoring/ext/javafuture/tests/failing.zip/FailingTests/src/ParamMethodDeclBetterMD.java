
import java.util.concurrent.Future;

public class ParamMethodDeclBetterMD {
	// Refactor
	public void retFuture(Future<Integer> f){

	}
	
	//Dont refactor because parameter variable cannot be refactored
	public void retFuture2(Future<Integer> f){
		f.cancel(true);
	}
	
	//Dont refactor bacause argument cannot be refactored
	public void retFuture3(Future<Integer> f){
	}

}
