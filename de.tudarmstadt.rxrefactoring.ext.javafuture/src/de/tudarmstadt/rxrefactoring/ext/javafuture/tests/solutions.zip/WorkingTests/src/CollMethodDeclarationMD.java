
import io.reactivex.Observable;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class CollMethodDeclarationMD {
	
	// Refactor
	public List<Observable<String>> retFuture(){
		ExecutorService exec = Executors.newSingleThreadExecutor();
		List<Observable<String>> cObservables = new ArrayList<Observable<String>>();
		cObservables.add(Observable.fromFuture(exec.submit(new MyCallable2())));
		return cObservables;
	}
	// Dont refactor
	public List<Future<String>> retFuture2(int i){
		ExecutorService exec = Executors.newSingleThreadExecutor();
		List<Future<String>> c = new ArrayList<Future<String>>();
		c.add(exec.submit(new MyCallable2()));
		return c;
	}

}
