
import io.reactivex.Observable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * This case makes sure that a Method Declaration that returns a Future
 * is not refactored if at least one value returned cannot be refactored.
 */
public class MethodDeclaration {
	
	//Refactor
	static Observable<Integer> fFObservable;
	
	public static void main(String[] args) throws Exception{
		
		MethodDeclarationMD md = new MethodDeclarationMD();
		// Refactor
		fFObservable = md.retFuture(); // Dont change method
		fFObservable.blockingSingle();
		
		// Dont refactor
		Future<String> f1 = md.retFuture2(1);
		f1.cancel(true);
		
		// Refactor
		Observable<String> f2Observable = Observable.fromFuture(md.retFuture2(1)); // Change method
		f2Observable.blockingSingle();
		
		// Refactor
		Observable<String> f3Observable = retFuture2(1); // Dont change method
		
		// Dont refactor
		Future<Integer> f4 = retFuture();
		f4.cancel(true);
		
		// Refactor
		Observable<Integer> f5Observable = Observable.fromFuture(retFuture()); // Change method
	}
	
	// Dont refactor
	public static Future<Integer> retFuture(){
		ExecutorService exec = Executors.newSingleThreadExecutor();
		return exec.submit(new MyCallable1());
	}
	
	// Refactor
	public static Observable<String> retFuture2(int i){
		ExecutorService exec = Executors.newSingleThreadExecutor();
		Observable<String> fObservable = Observable.fromFuture(exec.submit(new MyCallable2()));
		return fObservable;
	}

}



