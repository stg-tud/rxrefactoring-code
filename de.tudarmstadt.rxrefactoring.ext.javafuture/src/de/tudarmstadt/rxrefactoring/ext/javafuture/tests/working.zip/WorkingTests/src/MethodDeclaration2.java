
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * This case makes sure that a Method Declaration is not refactored if
 * the future it returns cannot be refactored for a method internal reason.
 */
public class MethodDeclaration2 {
	
	//Refactor
	static Future<Integer> fF;
	
	public static void main(String[] args) throws Exception{
		
		MethodDeclaration2MD md = new MethodDeclaration2MD();

		fF = md.retFuture(); // Dont change method
		
		Future<String> f1 = md.retFuture2(1); // Change method
		
		Future<Integer> f2 = retFuture(1); // Change method
		
		Future<String> f3 = retFuture2(1); // Dont change method
		
	}
	
	// Dont refactor
	public static Future<Integer> retFuture(int i){
		ExecutorService exec = Executors.newSingleThreadExecutor();
		Future<Integer> f1 = exec.submit(new MyCallable1());
		Future<Integer> f2 = exec.submit(new MyCallable1());
		f1.cancel(true);
		if (i<2) 
			return f1;
		else
			return f2;
	}
	
	// Refactor
	public static Future<String> retFuture2(int i){
		ExecutorService exec = Executors.newSingleThreadExecutor();
		Future<String> f = exec.submit(new MyCallable2());
		return f;
	}

}



